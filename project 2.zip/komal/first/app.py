from flask import Flask, redirect, render_template, request, redirect
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///xyz.db"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class Todo(db.Model):
    no = db.Column(db.Integer,primary_key=True)
    named = db.Column(db.String(25), nullable=False)
    email = db.Column(db.String(25), nullable=False) 
    password = db.Column(db.String(25), nullable=False)
    date_created = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self) -> str:
        return f"{self.no} - {self.email} - {self.named}"

@app.route("/", methods=['GET', 'POST'])
def hello_world():
    return render_template('index.html')

@app.route('/delete/<int:no>', methods=['GET' , 'POST'])
def delete(no):
    xyz = Todo.query.filter_by(no=no).first()
    db.session.delete(xyz)
    db.session.commit()
    return redirect('/register')
 

@app.route('/register', methods=['GET' , 'POST'])
def register():
    if request.method=='POST':
        named = request.form['named']
        email = request.form['email']
        password = request.form['password']
        xyz = Todo(named=named, email=email, password=password)
        db.session.add(xyz)
        db.session.commit()

    allTodo = Todo.query.all() 
    return render_template('registation.html', allTodo=allTodo) 
    
@app.route('/home', methods=['GET','POST'])
def home():
  return render_template('home.html')

@app.route('/form', methods=['GET','POST'])  
def form():
    return render_template('form.html')

@app.route('/booking', methods=['GET','POST'])
def booking():
    return render_template('booking.html') 

@app.route('/Reacipt', methods=['GET','POST'])
def reacipt():
    return render_template('reacipt.html')       

if __name__ == "__main__":
    app.run(debug=True, port=8000)