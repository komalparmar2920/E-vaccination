# E-vaccine
An online paltform for people to search and register Vaccine.
This Website is created with HTML and Python Flask.

## Steps to run on your local:
1. download python3 from https://www.python.org/downloads/
2. clone the repo.
3. install virtualenv from pip. `pip install virtualenv`
4. create virtual environment named env. `python -m virtualenv env`
5. run the virtualenv `.\env\Scripts\Activate.ps1`
6. install flask `pip install flask` to make flask webapp
7. install flask-sqlalchemy `pip install flask-sqlalchemy` for Databases
8. install flask-login `pip install Flask_login`
9. run the app.py file from `python .\flaskapp\app.py` 

#### Notes : If you are having issus running scripts. Consider below webpage for help.
https://www.stanleyulili.com/powershell/solution-to-running-scripts-is-disabled-on-this-system-error-on-powershell/
